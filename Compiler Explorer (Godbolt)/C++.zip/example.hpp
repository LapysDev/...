#include <cstdio>
#include <cstdlib>
#if (defined _MSVC_LANG ? _MSVC_LANG : __cplusplus) >= 202002L || (defined __circle_lang__ || defined __clang__ || defined __CUDACC_VER_BUILD__ || defined __CUDACC_VER_MAJOR__ || defined __CUDACC_VER_MINOR__ || defined __GNUC__ || defined __ICC || defined __INTEL_COMPILER || defined __INTEL_LLVM_COMPILER || defined __NVCC__ || defined __NVCOMPILER)
# include <version>
#endif
